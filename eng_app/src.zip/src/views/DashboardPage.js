import React from 'react';
import { Bar, Pie, Line } from 'react-chartjs-2';
import { Chart as ChartJS, registerables } from 'chart.js';
import { Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Grid, Typography } from '@mui/material';

ChartJS.register(...registerables);

function DashboardPage() {
    // Generating student mock data
    const studentData = Array.from({ length: 20 }, (_, index) => ({
        id: Math.floor(Math.random() * (19999 - 11111 + 1)) + 11111,
        finalResult: ['Pass', 'Fail', 'Withdraw', 'Distinction'][Math.floor(Math.random() * 4)],
        confidence: Math.floor(Math.random() * 28) + 55 // Random confidence between 60-80
    }));

    // Count predictions for charts
    const predictionCounts = studentData.reduce((acc, student) => {
        acc[student.finalResult] = (acc[student.finalResult] || 0) + 1;
        return acc;
    }, {});

    // Generate organic and random data progression of clicks for the line graph
    const generateRandomData = () => {
        let data = [];
        let value = 0;
        for (let i = 0; i < 123; i++) {
        // Random increase, higher at the start and end
        let increase = Math.random() * 500 + 100;
        if (i < 20 || i > 100) increase *= 1.5; // Increase more at the start and end
    
        value += increase;
        value = Math.min(value, 43530); // Ensure it doesn't exceed the maximum
        data.push(value);
        }
        return data;
    };
    
    const lineGraphData = {
        labels: Array.from({ length: 123 }, (_, i) => i - 10), // Days from -10 to 112
        datasets: [
        {
            label: 'Total Cumulative Interactions',
            data: generateRandomData(),
            fill: false,
            borderColor: 'rgb(75, 192, 192)',
            tension: 0.1
        }
        ]
    };
    
    const commonChartData = {
        labels: ['Fail', 'Withdraw', 'Pass', 'Distinction'],
        datasets: [
        {
            data: ['Fail', 'Withdraw', 'Pass', 'Distinction'].map(status => predictionCounts[status] || 0),
            backgroundColor: [
            'rgba(255, 99, 132, 0.5)',
            'rgba(255, 159, 64, 0.5)',
            'rgba(54, 162, 235, 0.5)',
            'rgba(153, 102, 255, 0.5)'
            ],
        }
        ]
    };

    return (
        <div style={{ padding: '20px' }}>
        <Grid container justifyContent="space-between" alignItems="center">
            <Grid item>
            <Typography variant="h4">Dashboard</Typography>
            </Grid>
            <Grid item>
            <Typography variant="h5" align="center">Course day 112</Typography>
            </Grid>
            <Grid item>
            <Typography variant="h5">Course code: AAA 2014J</Typography>
            </Grid>
        </Grid>

        <Grid container spacing={2} style={{ marginTop: '20px' }}>
            <Grid item xs={12} md={6}>
            <Bar data={commonChartData} />
            </Grid>
            <Grid item xs={12} md={6} style={{ display: 'flex', justifyContent: 'center' }}>
            <div style={{ width: '50%' }}>
                <Pie data={commonChartData} />
            </div>
            </Grid>
        </Grid>

        <Typography variant="h6" align="center" style={{ marginTop: '20px' }}>
        Total Online Learning Environment interactions per day
        </Typography>
        <div style={{ maxWidth: '60%', margin: 'auto' }}>
        <Line data={lineGraphData} />
        </div>

        <h2>Student Predictions</h2>
        <TableContainer component={Paper} style={{ marginTop: '20px' }}>
            <Table aria-label="student predictions">
            <TableHead>
                <TableRow>
                <TableCell>Student ID</TableCell>
                <TableCell align="right">Confidence (%)</TableCell>
                <TableCell align="right">Predicted Result</TableCell>
                </TableRow>
            </TableHead>
            <TableBody>
                {studentData.map((row) => (
                <TableRow key={row.id}>
                    <TableCell component="th" scope="row">
                    {row.id}
                    </TableCell>
                    <TableCell align="right">{row.confidence}</TableCell>
                    <TableCell align="right">{row.finalResult}</TableCell>
                </TableRow>
                ))}
            </TableBody>
            </Table>
        </TableContainer>
        </div>
    );
}

export default DashboardPage;
